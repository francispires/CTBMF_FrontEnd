export default interface IFile {
    url?: string;
    name: string;
}