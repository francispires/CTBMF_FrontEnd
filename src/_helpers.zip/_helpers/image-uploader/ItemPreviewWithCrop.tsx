import ReactCrop, {Crop} from "react-image-crop";
import {withRequestPreSendUpdate, useItemFinalizeListener, useItemStartListener} from "@rpldy/uploady";
//import { PREVIEW_TYPES } from "@rpldy/upload-preview";
import cropImage from "./cropImage.js";
import  {useCallback, useRef, useState} from "react";
import styled from "styled-components";
import {Button} from "@nextui-org/react";

const StyledReactCrop = styled(ReactCrop)`
  width: 100%;
  max-width: 900px;
  height: 400px;
  max-height: 400px;
`;

const PreviewImage = styled.img`
  margin: 5px;
  max-width: 200px;
  height: auto;
  max-height: 200px;
`;

const ButtonsWrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 10px;
`;

const PreviewButtons = ({
                            // finished=false,
                            // crop = {} as Crop,
                            // updateRequest = ()=>{return null},
                            onUploadCancel= ()=>{},
                            onUploadCrop= ()=>{},
                        }) => {
    return (
        <ButtonsWrapper>
            <Button onPress={onUploadCrop} color="primary">
                Upload
            </Button>
            <Button onPress={onUploadCancel} color="primary">
                Cancelar
            </Button>
        </ButtonsWrapper>
    );
};

const UPLOAD_STATES = {
    NONE: 0,
    UPLOADING: 1,
    FINISHED: 2,
};

export const ItemPreviewWithCrop = withRequestPreSendUpdate((props) => {
    const {
        id,
        // url,
        // isFallback,
        // type,
        // updateRequest,
        // requestData,
        // previewMethods,
    } = props;
    const [uploadState, setUploadState] = useState(UPLOAD_STATES.NONE);
    const [crop, setCrop] = useState({} as Crop);
    const [croppedUrl, setCroppedUrl] = useState("");
    const isFinished = uploadState === UPLOAD_STATES.FINISHED;
    const imgRef = useRef(null);

    useItemStartListener(() => setUploadState(UPLOAD_STATES.UPLOADING), id);
    useItemFinalizeListener(() => setUploadState(UPLOAD_STATES.FINISHED), id);

    const onUploadCrop = useCallback(async () => {
        if (updateRequest && (crop?.height || crop?.width)) {
            const {
                blob: croppedBlob,
                blobUrl,
                //revokeUrl,
            } = await cropImage(
                imgRef.current,
                requestData.items[0].file,
                crop,
                true
            );

            requestData.items[0].file = croppedBlob;

            updateRequest({ items: requestData.items });
            //setCroppedUrl({ blobUrl, revokeUrl });
            setCroppedUrl(blobUrl)
        }
    }, [requestData, updateRequest, crop]);

    const onUploadCancel = useCallback(() => {
        updateRequest(false);
        if (previewMethods.current?.clear) {
            previewMethods.current.clear();
        }
    }, [updateRequest, previewMethods]);

    //useEffect(() => () => croppedUrl?.revokeUrl(), [croppedUrl]);

    return isFallback || type !== "image" ? (
        <PreviewImage src={url} alt="fallback img" />
    ) : (
        <>
            {requestData && !isFinished ? (
                <StyledReactCrop crop={crop} onChange={setCrop}>
                    <img src={url} ref={imgRef} className="react-crop-img" />
                </StyledReactCrop>
            ) : (
                <PreviewImage src={croppedUrl?.blobUrl || url} alt="img to upload" />
            )}
            <PreviewButtons
                finished={isFinished}
                crop={crop}
                updateRequest={updateRequest}
                onUploadCancel={onUploadCancel}
                onUploadCrop={onUploadCrop}
            />
            <p>{isFinished ? "FINISHED" : ""}</p>
        </>
    );
});
