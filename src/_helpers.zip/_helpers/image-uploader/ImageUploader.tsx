import {useRef, RefObject, useMemo} from "react";
import "react-image-crop/dist/ReactCrop.css";
import Uploady from "@rpldy/uploady";
import { getMockSenderEnhancer } from "@rpldy/mock-sender";
import {asUploadButton} from "@rpldy/upload-button";
import UploadPreview, {PreviewComponentProps, PreviewMethods} from "@rpldy/upload-preview";
import {Image} from "@nextui-org/react";
import {ItemPreviewWithCrop} from "./ItemPreviewWithCrop.tsx"
import * as React from "react";


const mockSenderEnhancer = getMockSenderEnhancer({ delay: 1500 });


export type ImageUploaderProps = {
    blob: Blob;
    blobUrl: string;
}

export default function ImageUploader() {
    const previewMethodsRef = useRef();

    const ImageUploadButton = asUploadButton(() => {
        return <div style={{ cursor: "pointer" }}>
            <Image
                width="100%"
                height={200}
                alt=""
                    src="https://app.requestly.io/delay/1000/https://nextui-docs-v2.vercel.app/images/hero-card-complete.jpeg"
            />
        </div>
    });

    const previewComponent = useMemo(() => {
        return <ItemPreviewWithCrop id={""}/>
    }, []);

    return (
        <>
        <Uploady
            multiple={false}
            destination={{ url: "[upload-url]" }}
            enhancer={mockSenderEnhancer}
            autoUpload={true}
        >
            <div>
                <ImageUploadButton/>
                <br />
                <UploadPreview
                    PreviewComponent={previewComponent as unknown as React.FC<PreviewComponentProps>}
                    previewComponentProps={{ previewMethods: previewMethodsRef }}
                    previewMethodsRef={previewMethodsRef as unknown as RefObject<PreviewMethods>}
                    fallbackUrl="https://icon-library.net/images/image-placeholder-icon/image-placeholder-icon-6.jpg"
                />
            </div>
        </Uploady>
        </>
    );
}
