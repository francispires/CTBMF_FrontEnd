    // custom history object to allow navigation outside react components
export const history = {
    navigate: Function,
    location: {state: {from: {pathname: '/'}
    }}
};